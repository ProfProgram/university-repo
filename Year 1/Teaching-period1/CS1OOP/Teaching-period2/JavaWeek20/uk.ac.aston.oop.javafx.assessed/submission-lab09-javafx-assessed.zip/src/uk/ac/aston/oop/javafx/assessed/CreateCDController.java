package uk.ac.aston.oop.javafx.assessed;

import javafx.fxml.FXML;

public class CreateCDController {
	
	@FXML private javafx.scene.control.TextField titleField, artField;
	@FXML private javafx.scene.control.CheckBox ownCheck;
	@FXML private javafx.scene.control.Slider playSlide, trackSlide;
	@FXML private javafx.scene.control.Label playLabel, trackLabel;
	private boolean confirmed = false;
//	DoubleProperty listenPlaySlide, listenTrackSlide;
	
	public CreateCDController() {
		
	}
	
	/*
	 * Ways to get slider.getValue() as real value and as integer value
	 * System.out.println("Slider Val: "+trackSlide.getValue()); -> as double
	 * System.out.println("Slider Val as int: "+(int)trackSlide.getValue()); -> as int
	 */
	
	@FXML
	public void initialize() {
		final String playText = playLabel.getText();
		final String trackText = trackLabel.getText();
		playSlide.valueProperty().addListener((obs, oldVal, newVal)-> {
//			playSlide.setValue(Math.round(newVal.doubleValue()));
			int intVal = newVal.intValue();
			playLabel.setText(playText +  " " + intVal + " seconds");
			
		});
		trackSlide.valueProperty().addListener((obs, oldVal, newVal)-> {
//			trackSlide.setValue(Math.round(newVal.doubleValue()));
			int intVal = newVal.intValue();
			trackLabel.setText(trackText + " " + intVal);
			
		});
	}
	
	public boolean isConfirmed() {
		return this.confirmed;
	}
	
	// OnAction's
	@FXML
	public void createPressed() {
//		System.out.println("create was pressed!");
		this.confirmed = true;
		titleField.getScene().getWindow().hide();	
	}
	@FXML
	public void cancelPressed() {
		titleField.getScene().getWindow().hide();
	}
	
	// get methods for dialogue inputs
	public String getTitleText() {
		return titleField.getText();
	}
	public String getArtText() {
		return artField.getText();
	}
	public boolean isOwnChecked() {
		return ownCheck.isSelected();
	}
	public int getTime() {
		return (int)playSlide.getValue();
	}
	public int getNumTracks() {
		return (int)trackSlide.getValue();
	}
}
