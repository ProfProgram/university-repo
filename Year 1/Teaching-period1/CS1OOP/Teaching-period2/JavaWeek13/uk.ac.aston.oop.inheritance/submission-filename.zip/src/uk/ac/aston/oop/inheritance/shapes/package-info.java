/**
 * Package for holding all geometric shapes for inheritance lab program
 * 
 * @author 210163492
 * @version 1.0
 */
package uk.ac.aston.oop.inheritance.shapes;