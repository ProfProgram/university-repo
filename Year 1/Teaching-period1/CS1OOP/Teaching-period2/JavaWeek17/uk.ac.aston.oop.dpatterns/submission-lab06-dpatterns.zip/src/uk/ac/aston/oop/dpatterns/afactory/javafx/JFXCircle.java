package uk.ac.aston.oop.dpatterns.afactory.javafx;

import uk.ac.aston.oop.dpatterns.afactory.Circle;

public class JFXCircle implements Circle{
	
	private javafx.scene.shape.Circle circle;
	
	public JFXCircle(javafx.scene.Group container, int cx, int cy, int radius) {
		this.circle = new javafx.scene.shape.Circle();
		this.circle.setCenterX(cx);
		this.circle.setCenterY(cy);
		this.circle.setRadius(radius);
		container.getChildren().add(circle);
	}
	
	public void setFill(int r, int g, int b) {
		javafx.scene.paint.Color col = javafx.scene.paint.Color.rgb(r, g, b);
		circle.setFill(col);
	}
}
