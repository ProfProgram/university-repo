package uk.ac.aston.oop.rdd.sim;

public interface CountAwareActor extends Actor{
	
	public void setActorCount(Class actorClass, int count);
	
}
